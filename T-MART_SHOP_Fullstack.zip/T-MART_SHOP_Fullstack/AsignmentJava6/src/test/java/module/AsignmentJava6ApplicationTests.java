package module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsignmentJava6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
